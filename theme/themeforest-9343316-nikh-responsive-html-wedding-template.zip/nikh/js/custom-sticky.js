	
	'use strict';
	
	$(document).ready(function(){
			$("#nav").sticky({ topSpacing: 0 });
	});